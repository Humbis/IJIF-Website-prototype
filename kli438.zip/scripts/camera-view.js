document.getElementById("front-view").onclick = function(){
	document.getElementById("sample-player").src="img/front-surveillance.jpg";
}
document.getElementById("side-view").onclick = function(){
	document.getElementById("sample-player").src="img/side-surveillance.jpg";
}